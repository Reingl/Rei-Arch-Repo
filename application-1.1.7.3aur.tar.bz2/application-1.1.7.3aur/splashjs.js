/* == splashjs 1.0.0 == */

/* === configUtils.js === */

// configUtils.js
export async function loadConfig(configFile = 'serverhost.json') {
    const response = await fetch(configFile);
    if (!response.ok) throw new Error('Failed to load config');
    return await response.json();
}

export async function attemptLoadFromUrls(urlsToCheck) {
    let attemptsMade = 0;

function playOfflineSound() {
    const audio = document.getElementById('offlineerror');
    if (audio) {
        audio.play().catch(err => {
            console.warn('Autoplay blocked or failed:', err);
        });
    } else {
        console.warn('Offline audio element not found in DOM.');
    }
}    

    function showOfflineOverlay() {
        const overlay = document.getElementById('offline-overlay');
        const spinner = document.getElementById('spinner');

        if (overlay) {
            overlay.style.display = 'flex';
        } else {
            console.warn('Offline overlay element not found in DOM.');
        }

        if (spinner) {
            spinner.style.display = 'none';
            
        playOfflineSound();   
      }
    }

    function attemptSingleUrl(url) {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.timeout = 20000;

        xhr.ontimeout = function () {
            showOfflineOverlay();
        };

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status >= 200 && xhr.status < 300) {
                    window.location.href = xhr.responseURL || url;
                } else {
                    attemptsMade++;
                    if (attemptsMade < urlsToCheck.length) {
                        attemptSingleUrl(urlsToCheck[attemptsMade]);
                    } else {
                        showOfflineOverlay();
                    }
                }
            }
        };

        xhr.send();
    }

    attemptSingleUrl(urlsToCheck[attemptsMade]);
}

/* === appoffline.modular.test.js === */

document.addEventListener('DOMContentLoaded', async function () {
    const statusPill = document.getElementById('status-pill');
    const statusText = document.getElementById('status-text');
    const spinner = document.getElementById('spinner');
    const offlineOverlay = document.getElementById('offline-overlay');

    async function pingServer(url) {
        const start = performance.now();
        try {
            const response = await fetch(url, { method: 'HEAD', cache: 'no-store' });
            const end = performance.now();
            return response.ok ? end - start : null;
        } catch {
            return null;
        }
    }

    try {
        const config = await loadConfig();
        const urls = config.ServerUrls;

        if (!Array.isArray(urls) || urls.length === 0) {
            throw new Error("No ServerUrls found in config.");
        }

        const checkStatus = async () => {
            // Reset UI
            statusPill.classList.remove('green', 'red');
            statusPill.classList.add('yellow');
            statusText.textContent = "Checking status...";
            spinner.style.display = 'inline-block';

            await new Promise(resolve => setTimeout(resolve, 3000)); // 3s delay

            let online = false;
            let workingUrl = null;

            for (const url of urls) {
                const ping = await pingServer(url);
                if (ping !== null) {
                    online = true;
                    workingUrl = url;

                    statusPill.classList.remove('yellow');
                    statusPill.classList.add('green');
                    statusText.textContent = `Online (${ping.toFixed(1)} ms), redirecting...`;

                    setTimeout(() => {
                        window.location.href = workingUrl;
                    }, 1500);
                    break;
                }
            }

            if (!online) {
                statusPill.classList.remove('green', 'yellow');
                statusPill.classList.add('red');
                statusText.textContent = "Offline";
                if (offlineOverlay) offlineOverlay.style.display = 'flex';
            }

            spinner.style.display = 'none'; // Always hide spinner
        };

        checkStatus();
        setInterval(checkStatus, 30000);

    } catch (e) {
        console.error("Fatal error:", e);
        if (statusPill && statusText) {
            statusPill.classList.remove('green', 'yellow');
            statusPill.classList.add('red');
            statusText.textContent = "Offline";
        }
        if (offlineOverlay) offlineOverlay.style.display = 'flex';
        spinner.style.display = 'none';
    }
});



/* === serverload.modular.js === */

async function attemptLoadWithTimeout(timeoutMs = 10000, delayMs = 1500) {
    function showOfflineOverlay() {
        const overlay = document.getElementById('offline-overlay');
        if (overlay) {
            overlay.style.display = 'flex';
        } else {
            console.warn("Offline overlay element not found in DOM.");
        }
    }

    try {
        console.log(`⌛ Waiting ${delayMs / 1000} seconds before starting...`);
        await new Promise(resolve => setTimeout(resolve, delayMs));

        const config = await loadConfig();
        const urls = config.ServerUrls;
        if (!Array.isArray(urls)) {
            throw new Error("No valid ServerUrls in config");
        }

        // Countdown timer
        let secondsLeft = timeoutMs / 1000;
        const countdown = setInterval(() => {
            console.log(`⏳ Timeout in ${--secondsLeft} seconds...`);
            if (secondsLeft <= 0) clearInterval(countdown);
        }, 1000);

        // Race between attempt and timeout
        await Promise.race([
            attemptLoadFromUrls(urls),
            new Promise((_, reject) =>
                setTimeout(() => reject(new Error("Timeout reached")), timeoutMs)
            )
        ]);

        clearInterval(countdown);
    } catch (e) {
        console.error("❌ Server load failed or timed out:", e);
        showOfflineOverlay();
    }
}

attemptLoadWithTimeout();
